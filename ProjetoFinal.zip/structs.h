typedef struct Pais{
	char siglaPais[4], nomePais[15];
}tPais;

typedef struct Data{
	unsigned int dia, mes, ano;
}tData;

typedef struct Tempo{
	unsigned int hora, minuto, segundo, milissegundo;
}tTempo;

typedef struct Equipe{
	char nomeEquipe[21], siglaEquipe[4], paisOrigem[16];
}tEquipe;

typedef struct Piloto{
	int idPiloto;
	char nomePiloto[31], siglaEquipe[4], dataNascimento[11], paisOrigem[16];
	char sexoPiloto;
}tPiloto;

typedef struct Circuito{
	int idCircuito, idPiloto;
	char nomeCircuito[16], paisCircuito[16], tempoRecorde[14];
	float tamanhoCircuito;
}tCircuito;

typedef struct MelhorVolta{
	int id, idPiloto, idCircuito;
	char nomeEquipe[21], data[11], tempoRecorde[14];
}tMelhorVolta;
