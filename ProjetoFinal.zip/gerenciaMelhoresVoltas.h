#define ARQV_MELHORVOLTA "melhorVolta.bin"
#define MSG_ERRO "\n*** ENTRADA INVALIDA! ***\n\n"
