#define ARQV_MELHORESVOLTAS "melhorVolta.bin"
#define MSG_ERRO "\n*** ENTRADA INVALIDA! ***\n\n"
