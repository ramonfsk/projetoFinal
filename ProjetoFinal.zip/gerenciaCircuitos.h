#define ARQV_CIRCUITOS "circuitos.bin"
#define ARQV_PAISES "paises.txt"
#define MSG_ERRO "\n*** ENTRADA INVALIDA! ***\n\n"
