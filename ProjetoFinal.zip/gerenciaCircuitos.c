//Classe: Circuito

/* M�todos */

void cadastraCircuito(){
	
}

void alteraCircuito(){
	
}
