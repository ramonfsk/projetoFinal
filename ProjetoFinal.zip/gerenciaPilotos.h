/* Header */
#define ARQV_PILOTOS "pilotos.bin"
#define ARQV_EQUIPES "equipes.bin"
#define ARQV_PAISES "paises.txt"
#define QTD_IDSRAND 3
#define MAX_IDSRAND 101
#define MSG_ERRO "\n*** ENTRADA INVALIDA! ***\n\n"

void menuPilotoCRUD();
void cadastraPiloto();
//void alteraPiloto();
//void excluiPiloto();
/* Fun��es e Procedimentos da Classe Pilotos */
void selecionaIdRand();
void validaIdRepetido();
void validaNomePilotoRepetido();
void selecionaPais();
void selecionaSigla();
