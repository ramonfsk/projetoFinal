/* Header */
#define ARQV_PILOTOS "pilotos.bin"
#define ARQV_PAISES "paises.txt"

void menuPilotoCRUD(char *opcaoUsuario, int *validaInteracao);
//void cadastraPiloto();
//void alteraPiloto();
//void excluiPiloto();
